from ._lru import LRU as LRU  # noqa: F401

__all__ = ["LRU"]
