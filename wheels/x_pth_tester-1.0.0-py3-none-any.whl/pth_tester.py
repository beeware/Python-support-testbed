initialized = False


# The pth_tester module should be initalized by processing the `.pth` file
# created on installation.
def init():
    global initialized
    initialized = True
